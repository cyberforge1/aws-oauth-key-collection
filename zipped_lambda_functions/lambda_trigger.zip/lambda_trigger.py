# lambda_functions/lambda_trigger.py

import boto3
import json
import os

def get_secrets():
    # Retrieve the region automatically from the Lambda runtime environment
    aws_region = os.getenv('AWS_REGION', 'us-west-2')
    secrets_client = boto3.client('secretsmanager', region_name=aws_region)
    secret_name = "api_secrets"  # Replace with the actual secret name in Secrets Manager

    try:
        # Retrieve the secret
        response = secrets_client.get_secret_value(SecretId=secret_name)
        secret_data = json.loads(response['SecretString'])
        
        # Extract API_KEY and API_SECRET
        api_key = secret_data.get("API_KEY")
        api_secret = secret_data.get("API_SECRET")
        
        return api_key, api_secret
    except Exception as e:
        print("Error fetching secrets:", e)
        return None, None

def lambda_handler(event, context):
    print("Lambda function started.")
    
    # Fetch and print secrets
    api_key, api_secret = get_secrets()
    if api_key and api_secret:
        print("API_KEY:", api_key)
        print("API_SECRET:", api_secret)
    else:
        print("Failed to fetch secrets.")
    
    return {
        'statusCode': 200,
        'body': 'Lambda executed and secrets accessed successfully'
    }
